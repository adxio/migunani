<?php
header('Location: ../index.php/home/memberwelcome');
?>